(() => {
  "use strict";

  const API_BASE = (window.DT_BOT_API_BASE || "https://dt-bot-whatsapp.onrender.com").replace(/\/+$/, "");
  const SDK_VERSION = window.DT_META_GRAPH_API_VERSION || "v26.0";
  // App and configuration IDs are public by design. The secret stays only in
  // Render and is used by the backend while exchanging Meta's short-lived code.
  const META_APP_ID = window.DT_META_APP_ID || "1617679830370323";
  const META_CONFIG_ID = window.DT_META_EMBEDDED_SIGNUP_CONFIG_ID || "838280829331381";
  const TRIGGER_ID = "dt-embedded-signup-trigger";
  const STATUS_ID = "dt-embedded-signup-status";
  const CHECKLIST_ID = "dt-embedded-signup-checklist";
  let metaConfig = null;
  let configPromise = null;
  let pendingSignup = { code: "", wabaId: "", phoneNumberId: "", displayPhoneNumber: "", verifiedName: "", metaBusinessId: "", companyId: "", attemptId: "", finished: false };
  let completing = false;
  let sdkPromise = null;

  function currentCompanyId() {
    return window.__DT_CURRENT_COMPANY_ID ||
      window.localStorage.getItem("dt_crm_current_company_id") || "";
  }

  async function firebaseToken() {
    const auth = window.__DT_FIREBASE_AUTH;
    if (!auth || !auth.currentUser || typeof auth.currentUser.getIdToken !== "function") {
      throw new Error("Inicia sesión en el CRM antes de conectar WhatsApp.");
    }
    return auth.currentUser.getIdToken();
  }

  function setStatus(message, kind = "info") {
    const el = document.getElementById(STATUS_ID);
    if (!el) return;
    el.textContent = message;
    el.dataset.kind = kind;
    el.hidden = !message;
  }

  function ensureStyles() {
    if (document.getElementById("dt-embedded-signup-styles")) return;
    const style = document.createElement("style");
    style.id = "dt-embedded-signup-styles";
    style.textContent = `
      #${TRIGGER_ID} { display:inline-flex;align-items:center;gap:8px;margin:10px 0 0;padding:10px 14px;border:1px solid rgba(34,211,238,.45);border-radius:12px;background:linear-gradient(135deg,#083344,#164e63);color:#cffafe;font:700 12px/1.2 Inter,system-ui,sans-serif;cursor:pointer;box-shadow:0 8px 18px rgba(8,51,68,.25) }
      #${TRIGGER_ID}:hover { border-color:#22d3ee; filter:brightness(1.12) }
      #${TRIGGER_ID}[disabled] { opacity:.55;cursor:wait }
      #${STATUS_ID} { margin:8px 0 0;max-width:560px;color:#94a3b8;font:500 11px/1.45 Inter,system-ui,sans-serif }
      #${STATUS_ID}[data-kind="error"] { color:#fda4af }
      #${STATUS_ID}[data-kind="success"] { color:#86efac }
      #${STATUS_ID}[data-kind="warning"] { color:#fde68a }
      #${CHECKLIST_ID} { margin:8px 0 0;max-width:560px;color:#94a3b8;font:500 11px/1.5 Inter,system-ui,sans-serif }
      #${CHECKLIST_ID} strong { color:#cbd5e1 }
    `;
    document.head.appendChild(style);
  }

  function createTrigger() {
    if (document.getElementById(TRIGGER_ID)) return;
    ensureStyles();
    const trigger = document.createElement("button");
    trigger.id = TRIGGER_ID;
    trigger.type = "button";
    trigger.innerHTML = "🔗 Conectar WhatsApp con Meta";
    trigger.title = "El cliente autoriza su propia cuenta de Meta sin darte acceso total";
    trigger.addEventListener("click", launchSignup);
    const status = document.createElement("div");
    status.id = STATUS_ID;
    status.hidden = true;
    const checklist = document.createElement("div");
    checklist.id = CHECKLIST_ID;
    checklist.innerHTML = "<strong>Antes de empezar:</strong> entra con el administrador del portafolio de la empresa, ten a la mano el número y asegúrate de poder recibir su SMS o llamada de verificación. El CRM validará el número, suscribirá el webhook y mostrará el resultado antes de marcarlo como conectado.";

    const editButton = [...document.querySelectorAll("button")]
      .find((button) => /Editar Credenciales/i.test(button.textContent || ""));
    const anchor = editButton?.parentElement || [...document.querySelectorAll("main, #root")].pop();
    if (anchor) {
      anchor.appendChild(trigger);
      anchor.appendChild(checklist);
      anchor.appendChild(status);
    }
  }

  function sdkReady(appId) {
    return new Promise((resolve, reject) => {
      if (window.FB) {
        try {
          window.FB.init({ appId, cookie: true, xfbml: true, version: SDK_VERSION });
          resolve(window.FB);
        } catch (error) { reject(error); }
        return;
      }
      const previousInit = window.fbAsyncInit;
      window.fbAsyncInit = () => {
        if (typeof previousInit === "function") { try { previousInit(); } catch (_) {} }
        try {
          window.FB.init({ appId, cookie: true, xfbml: true, version: SDK_VERSION });
          resolve(window.FB);
        } catch (error) { reject(error); }
      };
      const script = document.createElement("script");
      script.async = true;
      script.defer = true;
      script.crossOrigin = "anonymous";
      script.src = "https://connect.facebook.net/es_LA/sdk.js";
      script.onerror = () => reject(new Error("No se pudo cargar el inicio de sesión seguro de Meta."));
      document.head.appendChild(script);
      setTimeout(() => reject(new Error("El SDK de Meta no respondió en este navegador.")), 7000);
    });
  }

  function preloadMetaSdk() {
    if (!sdkPromise) sdkPromise = sdkReady(META_APP_ID).catch(() => null);
    return sdkPromise;
  }

  async function loadMetaConfig() {
    if (configPromise) return configPromise;
    configPromise = (async () => {
      const token = await firebaseToken();
      const response = await fetch(`${API_BASE}/api/meta/embedded-signup/config`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const config = await response.json().catch(() => ({}));
      if (!response.ok || !config.enabled || !config.config_id) {
        throw new Error(config.error || "La conexión de Meta aún no está habilitada en el servidor.");
      }
      metaConfig = config;
      return config;
    })().catch((error) => {
      configPromise = null;
      throw error;
    });
    return configPromise;
  }

  async function prepareTenantActivation(companyId) {
    const token = await firebaseToken();
    const response = await fetch(`${API_BASE}/api/meta/embedded-signup/prepare`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${token}` },
      body: JSON.stringify({ company_id: companyId })
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok || !result.success) {
      throw new Error(result.error || "No se pudo preparar la activación de la empresa.");
    }
    return result;
  }

  function newAttemptId() {
    try {
      if (window.crypto && typeof window.crypto.randomUUID === "function") return window.crypto.randomUUID();
    } catch (_) {}
    return `wa_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
  }

  function parseSessionMessage(event) {
    if (!event || !["https://www.facebook.com", "https://web.facebook.com"].includes(event.origin)) return;
    let payload;
    try { payload = typeof event.data === "string" ? JSON.parse(event.data) : event.data; } catch (_) { return; }
    if (!payload || payload.type !== "WA_EMBEDDED_SIGNUP") return;
    const data = payload.data || {};
    pendingSignup.wabaId = data.waba_id || data.wabaId || pendingSignup.wabaId;
    pendingSignup.phoneNumberId = data.phone_number_id || data.phoneNumberId || pendingSignup.phoneNumberId;
    pendingSignup.displayPhoneNumber = data.display_phone_number || pendingSignup.displayPhoneNumber;
    pendingSignup.verifiedName = data.verified_name || pendingSignup.verifiedName;
    pendingSignup.metaBusinessId = data.business_id || data.businessId || pendingSignup.metaBusinessId;
    const button = document.getElementById(TRIGGER_ID);
    if (payload.event === "CANCEL") {
      setStatus("La conexión fue cancelada. No se guardó ningún cambio.", "warning");
      if (button) button.disabled = false;
    }
    else if (payload.event === "ERROR") {
      setStatus(data.error_message || "Meta reportó un error durante la conexión.", "error");
      if (button) button.disabled = false;
    }
    else if (["FINISH", "FINISH_ONLY_WABA", "FINISH_WHATSAPP_BUSINESS_APP_ONBOARDING"].includes(payload.event)) {
      pendingSignup.finished = true;
      if (!pendingSignup.wabaId || !pendingSignup.phoneNumberId) {
        setStatus("Meta terminó sin entregar el número seleccionado. No se guardó ningún cambio; vuelve a abrir el asistente y elige o registra un número.", "error");
        if (button) button.disabled = false;
        return;
      }
      setStatus("Meta confirmó la cuenta y el número. Validando la conexión y activando el webhook…", "info");
      maybeComplete();
    }
  }

  async function maybeComplete() {
    if (completing || !pendingSignup.finished || !pendingSignup.code || !pendingSignup.wabaId || !pendingSignup.phoneNumberId) return;
    completing = true;
    const button = document.getElementById(TRIGGER_ID);
    if (button) button.disabled = true;
    try {
      const token = await firebaseToken();
      const companyId = pendingSignup.companyId || currentCompanyId();
      if (!companyId) throw new Error("No se encontró la empresa activa del CRM.");
      const response = await fetch(`${API_BASE}/api/meta/embedded-signup/complete`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": `Bearer ${token}` },
        body: JSON.stringify({
          code: pendingSignup.code,
          company_id: companyId,
          waba_id: pendingSignup.wabaId,
          phone_number_id: pendingSignup.phoneNumberId,
          display_phone_number: pendingSignup.displayPhoneNumber,
          verified_name: pendingSignup.verifiedName,
          meta_business_id: pendingSignup.metaBusinessId
          ,attempt_id: pendingSignup.attemptId
        })
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok || !result.success) throw new Error(result.error || "No se pudo completar la conexión.");
      setStatus(`✅ WhatsApp conectado: ${result.display_phone_number || result.phone_number_id}. Actualizando el CRM…`, "success");
      setTimeout(() => window.location.reload(), 1200);
    } catch (error) {
      setStatus(`No se pudo completar la conexión: ${error.message}`, "error");
      if (button) button.disabled = false;
      completing = false;
    }
  }

  async function launchSignup() {
    const button = document.getElementById(TRIGGER_ID);
    if (button) button.disabled = true;
    setStatus("Preparando el inicio de sesión seguro de Meta…", "info");
    const cardCompanyId = (document.body?.innerText || "").match(/company_id=([A-Za-z0-9_-]+)/i)?.[1] || "";
    pendingSignup = { code: "", wabaId: "", phoneNumberId: "", displayPhoneNumber: "", verifiedName: "", metaBusinessId: "", companyId: cardCompanyId || currentCompanyId(), attemptId: newAttemptId(), finished: false };
    try {
      // The SDK is loaded before the click. Keeping FB.login in this click
      // avoids browser popup blockers and, crucially, never falls back to a
      // regular OAuth screen that has no selected WhatsApp account or number.
      if (!pendingSignup.companyId) throw new Error("Selecciona primero la empresa que recibirá este número.");
      if (!window.FB) throw new Error("El asistente seguro de Meta aún está cargando. Vuelve a intentarlo en unos segundos.");
      const config = await loadMetaConfig();
      if (!config || !config.enabled || !config.config_id) throw new Error("Falta activar la configuración de Registro insertado de WhatsApp en la app de Meta.");
      await prepareTenantActivation(pendingSignup.companyId);
      setStatus("Empresa preparada. Continúa en Meta para autorizar su WABA y número de WhatsApp…", "info");
      window.removeEventListener("message", parseSessionMessage);
      window.addEventListener("message", parseSessionMessage);
      await sdkReady(metaConfig.app_id);
    // Activar WhatsApp Business App Coexistence: el cliente mantiene
    // WhatsApp Business en su teléfono y, al mismo tiempo, conecta el
    // número con Cloud API para el bot del CRM.
    const extras = {
      setup: {},
      sessionInfoVersion: "3",
      featureType: "whatsapp_business_app_onboarding"
    };
      window.FB.login((response) => {
        const authResponse = response && response.authResponse;
        if (!authResponse) {
          setStatus("El inicio de sesión de Meta fue cancelado o no recibió autorización.", "warning");
          if (button) button.disabled = false;
          return;
        }
        pendingSignup.code = authResponse.code || "";
        if (!pendingSignup.code) {
          setStatus("Meta no devolvió el código temporal requerido para completar la conexión.", "error");
          if (button) button.disabled = false;
          return;
        }
        if (pendingSignup.finished) maybeComplete();
        else setStatus("Continúa en el asistente de Meta y selecciona la cuenta y el número de WhatsApp. El CRM no guardará nada hasta recibir esa confirmación.", "info");
      }, { config_id: config.config_id, response_type: "code", override_default_response_type: true, extras });
    } catch (error) {
      setStatus(error.message, "error");
      if (button) button.disabled = false;
    }
  }

  function shouldAttach() {
    const text = document.body?.innerText || "";
    return /Meta WhatsApp Cloud API Oficial|Centro de Integraciones|Conectar WhatsApp Business Platform/i.test(text);
  }

  function observe() {
    const attach = () => { if (shouldAttach()) createTrigger(); };
    preloadMetaSdk();
    // Load the server-side configuration while idle. launchSignup repeats the
    // check immediately before opening Meta, so a stale or incomplete setup
    // never sends a customer into a dead-end popup.
    loadMetaConfig().catch(() => {});
    attach();
    new MutationObserver(attach).observe(document.documentElement, { childList: true, subtree: true });
  }

  window.DTEmbeddedSignup = { launch: launchSignup };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", observe);
  else observe();
})();
