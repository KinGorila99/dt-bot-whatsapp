(() => {
  "use strict";

  const API_BASE = (window.DT_BOT_API_BASE || "https://dt-bot-whatsapp.onrender.com").replace(/\/+$/, "");
  const SDK_VERSION = window.DT_META_GRAPH_API_VERSION || "v21.0";
  const TRIGGER_ID = "dt-embedded-signup-trigger";
  const STATUS_ID = "dt-embedded-signup-status";
  let metaConfig = null;
  let pendingSignup = { code: "", wabaId: "", phoneNumberId: "", displayPhoneNumber: "", verifiedName: "" };
  let completing = false;

  function currentCompanyId() {
    return window.__DT_CURRENT_COMPANY_ID ||
      window.localStorage.getItem("dt_crm_current_company_id") || "";
  }

  async function firebaseToken() {
    const auth = window.__DT_FIREBASE_AUTH;
    if (!auth || !auth.currentUser || typeof auth.currentUser.getIdToken !== "function") {
      throw new Error("Inicia sesión en el CRM antes de conectar WhatsApp.");
    }
    return auth.currentUser.getIdToken();
  }

  function setStatus(message, kind = "info") {
    const el = document.getElementById(STATUS_ID);
    if (!el) return;
    el.textContent = message;
    el.dataset.kind = kind;
    el.hidden = !message;
  }

  function ensureStyles() {
    if (document.getElementById("dt-embedded-signup-styles")) return;
    const style = document.createElement("style");
    style.id = "dt-embedded-signup-styles";
    style.textContent = `
      #${TRIGGER_ID} { display:inline-flex;align-items:center;gap:8px;margin:10px 0 0;padding:10px 14px;border:1px solid rgba(34,211,238,.45);border-radius:12px;background:linear-gradient(135deg,#083344,#164e63);color:#cffafe;font:700 12px/1.2 Inter,system-ui,sans-serif;cursor:pointer;box-shadow:0 8px 18px rgba(8,51,68,.25) }
      #${TRIGGER_ID}:hover { border-color:#22d3ee; filter:brightness(1.12) }
      #${TRIGGER_ID}[disabled] { opacity:.55;cursor:wait }
      #${STATUS_ID} { margin:8px 0 0;max-width:560px;color:#94a3b8;font:500 11px/1.45 Inter,system-ui,sans-serif }
      #${STATUS_ID}[data-kind="error"] { color:#fda4af }
      #${STATUS_ID}[data-kind="success"] { color:#86efac }
      #${STATUS_ID}[data-kind="warning"] { color:#fde68a }
    `;
    document.head.appendChild(style);
  }

  function createTrigger() {
    if (document.getElementById(TRIGGER_ID)) return;
    ensureStyles();
    const trigger = document.createElement("button");
    trigger.id = TRIGGER_ID;
    trigger.type = "button";
    trigger.innerHTML = "🔗 Conectar WhatsApp con Meta";
    trigger.title = "El cliente autoriza su propia cuenta de Meta sin darte acceso total";
    trigger.addEventListener("click", launchSignup);
    const status = document.createElement("div");
    status.id = STATUS_ID;
    status.hidden = true;

    const editButton = [...document.querySelectorAll("button")]
      .find((button) => /Editar Credenciales/i.test(button.textContent || ""));
    const anchor = editButton?.parentElement || [...document.querySelectorAll("main, #root")].pop();
    if (anchor) {
      anchor.appendChild(trigger);
      anchor.appendChild(status);
    }
  }

  function sdkReady(appId) {
    return new Promise((resolve, reject) => {
      if (window.FB) {
        try {
          window.FB.init({ appId, cookie: true, xfbml: true, version: SDK_VERSION });
          resolve(window.FB);
        } catch (error) { reject(error); }
        return;
      }
      const previousInit = window.fbAsyncInit;
      window.fbAsyncInit = () => {
        if (typeof previousInit === "function") { try { previousInit(); } catch (_) {} }
        try {
          window.FB.init({ appId, cookie: true, xfbml: true, version: SDK_VERSION });
          resolve(window.FB);
        } catch (error) { reject(error); }
      };
      const script = document.createElement("script");
      script.async = true;
      script.defer = true;
      script.crossOrigin = "anonymous";
      script.src = "https://connect.facebook.net/es_LA/sdk.js";
      script.onerror = () => reject(new Error("No se pudo cargar el inicio de sesión seguro de Meta."));
      document.head.appendChild(script);
    });
  }

  function parseSessionMessage(event) {
    if (!event || !["https://www.facebook.com", "https://web.facebook.com"].includes(event.origin)) return;
    let payload;
    try { payload = typeof event.data === "string" ? JSON.parse(event.data) : event.data; } catch (_) { return; }
    if (!payload || payload.type !== "WA_EMBEDDED_SIGNUP") return;
    const data = payload.data || {};
    pendingSignup.wabaId = data.waba_id || data.wabaId || pendingSignup.wabaId;
    pendingSignup.phoneNumberId = data.phone_number_id || data.phoneNumberId || pendingSignup.phoneNumberId;
    pendingSignup.displayPhoneNumber = data.display_phone_number || pendingSignup.displayPhoneNumber;
    pendingSignup.verifiedName = data.verified_name || pendingSignup.verifiedName;
    if (payload.event === "CANCEL") setStatus("La conexión fue cancelada. No se guardó ningún cambio.", "warning");
    else if (payload.event === "ERROR") setStatus(data.error_message || "Meta reportó un error durante la conexión.", "error");
    else if (["FINISH", "FINISH_ONLY_WABA", "FINISH_WHATSAPP_BUSINESS_APP_ONBOARDING"].includes(payload.event)) {
      setStatus("Meta terminó el registro. Validando la cuenta y activando el webhook…", "info");
      maybeComplete();
    }
  }

  async function maybeComplete() {
    if (completing || !pendingSignup.code || !pendingSignup.wabaId) return;
    completing = true;
    const button = document.getElementById(TRIGGER_ID);
    if (button) button.disabled = true;
    try {
      const token = await firebaseToken();
      const companyId = currentCompanyId();
      if (!companyId) throw new Error("No se encontró la empresa activa del CRM.");
      const response = await fetch(`${API_BASE}/api/meta/embedded-signup/complete`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": `Bearer ${token}` },
        body: JSON.stringify({
          code: pendingSignup.code,
          company_id: companyId,
          waba_id: pendingSignup.wabaId,
          phone_number_id: pendingSignup.phoneNumberId,
          display_phone_number: pendingSignup.displayPhoneNumber,
          verified_name: pendingSignup.verifiedName
        })
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok || !result.success) throw new Error(result.error || "No se pudo completar la conexión.");
      setStatus(`✅ WhatsApp conectado: ${result.display_phone_number || result.phone_number_id}. Actualizando el CRM…`, "success");
      setTimeout(() => window.location.reload(), 1200);
    } catch (error) {
      setStatus(`No se pudo completar la conexión: ${error.message}`, "error");
      if (button) button.disabled = false;
      completing = false;
    }
  }

  async function launchSignup() {
    const button = document.getElementById(TRIGGER_ID);
    if (button) button.disabled = true;
    setStatus("Preparando el inicio de sesión seguro de Meta…", "info");
    pendingSignup = { code: "", wabaId: "", phoneNumberId: "", displayPhoneNumber: "", verifiedName: "" };
    try {
      const token = await firebaseToken();
      const configResponse = await fetch(`${API_BASE}/api/meta/embedded-signup/config`, { headers: { Authorization: `Bearer ${token}` } });
      metaConfig = await configResponse.json().catch(() => ({}));
      if (!configResponse.ok || !metaConfig.enabled) throw new Error("Falta activar la configuración de Embedded Signup en la app de Meta.");
      window.removeEventListener("message", parseSessionMessage);
      window.addEventListener("message", parseSessionMessage);
      await sdkReady(metaConfig.app_id);
      const extras = { setup: {}, sessionInfoVersion: "3" };
      window.FB.login((response) => {
        const authResponse = response && response.authResponse;
        if (!authResponse) {
          setStatus("El inicio de sesión de Meta fue cancelado o no recibió autorización.", "warning");
          if (button) button.disabled = false;
          return;
        }
        pendingSignup.code = authResponse.code || "";
        if (!pendingSignup.code) {
          setStatus("Meta no devolvió el código temporal requerido para completar la conexión.", "error");
          if (button) button.disabled = false;
          return;
        }
        maybeComplete();
      }, { config_id: metaConfig.config_id, response_type: "code", override_default_response_type: true, extras });
    } catch (error) {
      setStatus(error.message, "error");
      if (button) button.disabled = false;
    }
  }

  function shouldAttach() {
    const text = document.body?.innerText || "";
    return /Meta WhatsApp Cloud API Oficial|Centro de Integraciones|Conectar WhatsApp Business Platform/i.test(text);
  }

  function observe() {
    const attach = () => { if (shouldAttach()) createTrigger(); };
    attach();
    new MutationObserver(attach).observe(document.documentElement, { childList: true, subtree: true });
  }

  window.DTEmbeddedSignup = { launch: launchSignup };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", observe);
  else observe();
})();
